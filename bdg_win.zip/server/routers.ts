import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { users } from "../drizzle/schema";
import {
  getUserById,
  updateUserBalance,
  getAllGames,
  getGamesByCategory,
  createBet,
  updateBet,
  getUserBets,
  createTransaction,
  getUserTransactions,
  createWithdrawalRequest,
  getPendingWithdrawalRequests,
  updateWithdrawalRequest,
  getAgentReferrals,
  createReferral,
  getAllPromotions,
  getGameSession,
  updateGameSession,
  getDailyCommission,
  createDailyCommission,
  getAgentDailyCommissions,
  getDb,
} from "./db";
import {
  generateServerSeed,
  generateClientSeed,
  generateRandomNumber,
  calculateRTPWeightedOutcome,
  generateAgentCode,
  calculateAgentCommission,
} from "./gameLogic";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Wallet & Balance
  wallet: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      return {
        balance: user?.balance || "0",
        totalDeposited: user?.totalDeposited || "0",
        totalWithdrawn: user?.totalWithdrawn || "0",
        vipLevel: user?.vipLevel || 0,
        receivedWelcomeBonus: user?.receivedWelcomeBonus || false,
      };
    }),

    deposit: protectedProcedure
      .input(
        z.object({
          amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const user = await getUserById(ctx.user.id);
        if (!user) throw new Error("User not found");

        const depositAmount = parseFloat(input.amount);
        const newBalance = (parseFloat(user.balance) + depositAmount).toFixed(2);

        // Update user balance
        await updateUserBalance(ctx.user.id, newBalance);

        // Record transaction
        await createTransaction({
          userId: ctx.user.id,
          type: "deposit",
          amount: input.amount,
          balanceBefore: user.balance,
          balanceAfter: newBalance,
          status: "completed",
          description: `Deposit of ₹${input.amount}`,
        });

        return { success: true, newBalance };
      }),

    claimWelcomeBonus: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const user = await getUserById(ctx.user.id);
      if (!user) throw new Error("User not found");

      if (user.receivedWelcomeBonus) {
        throw new Error("Welcome bonus already claimed");
      }

      const bonusAmount = "500";
      const newBalance = (parseFloat(user.balance) + 500).toFixed(2);

      // Update user balance and mark bonus as received
      await db
        .update(users)
        .set({
          balance: newBalance,
          receivedWelcomeBonus: true,
          updatedAt: new Date(),
        })
        .where(eq(users.id, ctx.user.id));

      // Record transaction
      await createTransaction({
        userId: ctx.user.id,
        type: "bonus",
        amount: bonusAmount,
        balanceBefore: user.balance,
        balanceAfter: newBalance,
        status: "completed",
        description: "Welcome bonus: Get ₹500 bonus",
      });

      return { success: true, newBalance };
    }),

    requestWithdrawal: protectedProcedure
      .input(
        z.object({
          amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
          bankCardNumber: z.string().min(10),
          bankName: z.string(),
          cardHolderName: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const user = await getUserById(ctx.user.id);
        if (!user) throw new Error("User not found");

        const withdrawAmount = parseFloat(input.amount);
        const userBalance = parseFloat(user.balance);

        if (withdrawAmount > userBalance) {
          throw new Error("Insufficient balance");
        }

        if (withdrawAmount < 1000) {
          throw new Error("Minimum withdrawal is ₹1000");
        }

        if (withdrawAmount > 99999) {
          throw new Error("Maximum withdrawal is ₹99999");
        }

        // Create withdrawal request
        const requestId = await createWithdrawalRequest({
          userId: ctx.user.id,
          amount: input.amount,
          bankCardNumber: input.bankCardNumber, // In production, encrypt this
          bankName: input.bankName,
          cardHolderName: input.cardHolderName,
          status: "pending",
        });

        // Record transaction
        await createTransaction({
          userId: ctx.user.id,
          type: "withdrawal",
          amount: input.amount,
          balanceBefore: user.balance,
          balanceAfter: userBalance.toFixed(2),
          status: "pending",
          withdrawalRequestId: requestId,
          description: `Withdrawal request of ₹${input.amount}`,
        });

        return { success: true, requestId };
      }),

    getTransactions: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return await getUserTransactions(ctx.user.id, input.limit);
      }),
  }),

  // Games
  games: router({
    getAll: publicProcedure.query(async () => {
      return await getAllGames();
    }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return await getGamesByCategory(input.category);
      }),

    getSession: publicProcedure
      .input(z.object({ gameId: z.string() }))
      .query(async ({ input }) => {
        return await getGameSession(input.gameId);
      }),
  }),

  // Betting
  bets: router({
    placeBet: protectedProcedure
      .input(
        z.object({
          gameId: z.string(),
          betAmount: z.string().regex(/^\d+(\.\d{1,2})?$/),
          clientSeed: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const user = await getUserById(ctx.user.id);
        if (!user) throw new Error("User not found");

        const betAmount = parseFloat(input.betAmount);
        const userBalance = parseFloat(user.balance);

        if (betAmount > userBalance) {
          throw new Error("Insufficient balance");
        }

        // Create bet record
        const betId = nanoid();
        const serverSeed = generateServerSeed();
        const nonce = Math.floor(Math.random() * 1000000);

        await createBet({
          id: betId,
          userId: ctx.user.id,
          gameId: input.gameId,
          betAmount: input.betAmount,
          status: "pending",
          clientSeed: input.clientSeed,
          serverSeed,
          nonce,
          gameData: {},
          createdAt: new Date(),
        });

        // Deduct bet from balance
        const newBalance = (userBalance - betAmount).toFixed(2);
        await updateUserBalance(ctx.user.id, newBalance);

        // Record bet transaction
        await createTransaction({
          userId: ctx.user.id,
          type: "bet",
          amount: input.betAmount,
          balanceBefore: user.balance,
          balanceAfter: newBalance,
          status: "completed",
          gameId: input.gameId,
          betId,
          description: `Bet placed on ${input.gameId}`,
        });

        return {
          betId,
          serverSeed,
          nonce,
          newBalance,
        };
      }),

    resolveBet: protectedProcedure
      .input(
        z.object({
          betId: z.string(),
          gameId: z.string(),
          rtp: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const user = await getUserById(ctx.user.id);
        if (!user) throw new Error("User not found");

        // Get bet details
        const bet = await createBet({
          id: input.betId,
          userId: ctx.user.id,
          gameId: input.gameId,
          betAmount: "0",
          status: "pending",
          clientSeed: "",
          serverSeed: "",
          nonce: 0,
          gameData: {},
        });

        // Generate random outcome
        const randomValue = generateRandomNumber(
          "", // clientSeed
          "", // serverSeed
          0, // nonce
          0,
          1
        );

        const outcome = calculateRTPWeightedOutcome(input.rtp, parseFloat("0"), randomValue);

        const betAmount = parseFloat("0");
        const resultAmount = outcome.won ? betAmount * outcome.multiplier : 0;
        const newBalance = (parseFloat(user.balance) + resultAmount).toFixed(2);

        // Update bet
        await updateBet(input.betId, {
          status: outcome.won ? "won" : "lost",
          resultAmount: resultAmount.toFixed(2),
          resultData: { multiplier: outcome.multiplier, won: outcome.won },
          completedAt: new Date(),
        });

        // Update user balance
        await updateUserBalance(ctx.user.id, newBalance);

        // Record win/loss transaction
        if (outcome.won) {
          await createTransaction({
            userId: ctx.user.id,
            type: "win",
            amount: resultAmount.toFixed(2),
            balanceBefore: user.balance,
            balanceAfter: newBalance,
            status: "completed",
            gameId: input.gameId,
            betId: input.betId,
            description: `Won ₹${resultAmount.toFixed(2)} on ${input.gameId}`,
          });
        }

        return {
          won: outcome.won,
          multiplier: outcome.multiplier,
          resultAmount: resultAmount.toFixed(2),
          newBalance,
        };
      }),

    getUserBets: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return await getUserBets(ctx.user.id, input.limit);
      }),
  }),

  // Agent/Referral System
  agent: router({
    getOrCreateCode: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const user = await getUserById(ctx.user.id);
      if (!user) throw new Error("User not found");

      if (user.agentCode) {
        return { agentCode: user.agentCode };
      }

      const agentCode = generateAgentCode();
      // Update user with agent code in database
      await db
        .update(users)
        .set({
          isAgent: true,
          agentCode,
          updatedAt: new Date(),
        })
        .where(eq(users.id, ctx.user.id));

      return { agentCode };
    }),

    getReferrals: protectedProcedure.query(async ({ ctx }) => {
      return await getAgentReferrals(ctx.user.id);
    }),

    getDailyCommissions: protectedProcedure
      .input(z.object({ limit: z.number().default(30) }))
      .query(async ({ ctx, input }) => {
        return await getAgentDailyCommissions(ctx.user.id, input.limit);
      }),

    getTotalCommissions: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      return {
        totalCommissionEarned: user?.totalCommissionEarned || "0",
      };
    }),
  }),

  // Promotions
  promotions: router({
    getAll: publicProcedure.query(async () => {
      return await getAllPromotions();
    }),
  }),

  // Admin functions
  admin: router({
    getPendingWithdrawals: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      return await getPendingWithdrawalRequests();
    }),

    approveWithdrawal: protectedProcedure
      .input(z.object({ requestId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }

        await updateWithdrawalRequest(input.requestId, {
          status: "approved",
          approvedBy: ctx.user.id,
          updatedAt: new Date(),
        });

        return { success: true };
      }),

    rejectWithdrawal: protectedProcedure
      .input(z.object({ requestId: z.number(), reason: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }

        await updateWithdrawalRequest(input.requestId, {
          status: "rejected",
          approvedBy: ctx.user.id,
          approvalNotes: input.reason,
          updatedAt: new Date(),
        });

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
