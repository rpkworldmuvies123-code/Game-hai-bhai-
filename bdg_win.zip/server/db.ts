import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  games,
  bets,
  transactions,
  referrals,
  withdrawalRequests,
  dailyCommissions,
  promotions,
  gameSessions,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserBalance(userId: number, newBalance: string) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(users)
    .set({ balance: newBalance, updatedAt: new Date() })
    .where(eq(users.id, userId));
}

export async function getGameById(gameId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(games)
    .where(eq(games.id, gameId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getAllGames() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(games)
    .where(eq(games.isActive, true));
}

export async function getGamesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(games)
    .where(and(eq(games.category, category as any), eq(games.isActive, true)));
}

export async function createBet(betData: any) {
  const db = await getDb();
  if (!db) return null;

  await db.insert(bets).values(betData);
  return betData.id;
}

export async function getBetById(betId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(bets)
    .where(eq(bets.id, betId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateBet(betId: string, updates: any) {
  const db = await getDb();
  if (!db) return;

  await db.update(bets).set(updates).where(eq(bets.id, betId));
}

export async function getUserBets(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(bets)
    .where(eq(bets.userId, userId))
    .orderBy(desc(bets.createdAt))
    .limit(limit);
}

export async function createTransaction(transactionData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(transactions).values(transactionData);
  return result[0]?.insertId;
}

export async function getUserTransactions(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

export async function createWithdrawalRequest(requestData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(withdrawalRequests).values(requestData);
  return result[0]?.insertId;
}

export async function getWithdrawalRequest(requestId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(withdrawalRequests)
    .where(eq(withdrawalRequests.id, requestId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getPendingWithdrawalRequests() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(withdrawalRequests)
    .where(eq(withdrawalRequests.status, "pending"))
    .orderBy(withdrawalRequests.createdAt);
}

export async function updateWithdrawalRequest(requestId: number, updates: any) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(withdrawalRequests)
    .set(updates)
    .where(eq(withdrawalRequests.id, requestId));
}

export async function createReferral(referralData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(referrals).values(referralData);
  return result[0]?.insertId;
}

export async function getAgentReferrals(agentUserId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(referrals)
    .where(eq(referrals.agentUserId, agentUserId));
}

export async function updateReferral(referralId: number, updates: any) {
  const db = await getDb();
  if (!db) return;

  await db.update(referrals).set(updates).where(eq(referrals.id, referralId));
}

export async function createDailyCommission(commissionData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(dailyCommissions).values(commissionData);
  return result[0]?.insertId;
}

export async function getDailyCommission(agentUserId: number, date: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(dailyCommissions)
    .where(
      and(
        eq(dailyCommissions.agentUserId, agentUserId),
        eq(dailyCommissions.commissionDate, date)
      )
    )
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getAgentDailyCommissions(agentUserId: number, limit: number = 30) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(dailyCommissions)
    .where(eq(dailyCommissions.agentUserId, agentUserId))
    .orderBy(desc(dailyCommissions.commissionDate))
    .limit(limit);
}

export async function getAllPromotions() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(promotions)
    .where(eq(promotions.isActive, true));
}

export async function getGameSession(gameId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(gameSessions)
    .where(eq(gameSessions.gameId, gameId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateGameSession(gameId: string, activePlayers: number) {
  const db = await getDb();
  if (!db) return;

  const existing = await getGameSession(gameId);
  if (existing) {
    await db
      .update(gameSessions)
      .set({ activePlayers, lastUpdated: new Date() })
      .where(eq(gameSessions.gameId, gameId));
  } else {
    await db.insert(gameSessions).values({
      id: `session_${gameId}_${Date.now()}`,
      gameId,
      activePlayers,
    });
  }
}
