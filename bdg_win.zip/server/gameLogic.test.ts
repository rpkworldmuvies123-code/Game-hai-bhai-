import { describe, it, expect } from "vitest";
import {
  generateServerSeed,
  generateClientSeed,
  generateRandomNumber,
  calculateRTPWeightedOutcome,
  generateAviatorCrashPoint,
  generateMinesPositions,
  generatePlinkoResult,
  generateLimboNumber,
  generateSlotReels,
  calculateSlotWinnings,
  generateColorPredictionResult,
  calculateAgentCommission,
  generateAgentCode,
} from "./gameLogic";

describe("Game Logic", () => {
  describe("Seed Generation", () => {
    it("should generate server seed", () => {
      const seed = generateServerSeed();
      expect(seed).toHaveLength(64);
      expect(/^[a-f0-9]{64}$/.test(seed)).toBe(true);
    });

    it("should generate client seed", () => {
      const seed = generateClientSeed();
      expect(seed).toHaveLength(32);
      expect(/^[a-f0-9]{32}$/.test(seed)).toBe(true);
    });
  });

  describe("Random Number Generation", () => {
    it("should generate number within range", () => {
      const num = generateRandomNumber("client", "server", 1, 0, 100);
      expect(num).toBeGreaterThanOrEqual(0);
      expect(num).toBeLessThanOrEqual(100);
    });

    it("should be deterministic with same inputs", () => {
      const num1 = generateRandomNumber("client", "server", 1, 0, 1);
      const num2 = generateRandomNumber("client", "server", 1, 0, 1);
      expect(num1).toBe(num2);
    });
  });

  describe("RTP-Weighted Outcomes", () => {
    it("should respect RTP threshold", () => {
      const rtp = 96; // 96% RTP
      const outcomes = [];

      for (let i = 0; i < 100; i++) {
        const randomValue = i / 100;
        const outcome = calculateRTPWeightedOutcome(rtp, 100, randomValue);
        outcomes.push(outcome.won ? 1 : 0);
      }

      const winRate = outcomes.reduce((a, b) => a + b, 0) / outcomes.length;
      expect(winRate).toBeCloseTo(0.96, 1);
    });

    it("should calculate reasonable multipliers", () => {
      const outcome = calculateRTPWeightedOutcome(96, 100, 0.5);
      if (outcome.won) {
        expect(outcome.multiplier).toBeGreaterThanOrEqual(1.1);
        expect(outcome.multiplier).toBeLessThanOrEqual(3);
      }
    });
  });

  describe("Aviator Game", () => {
    it("should generate crash point", () => {
      const point = generateAviatorCrashPoint(96, 0.5);
      expect(point).toBeGreaterThan(1);
      expect(point).toBeLessThanOrEqual(20);
    });

    it("should crash earlier for low RTP values", () => {
      const pointHigh = generateAviatorCrashPoint(96, 0.99);
      const pointLow = generateAviatorCrashPoint(96, 0.01);
      // Both should be valid, just testing they're generated
      expect(pointHigh).toBeGreaterThan(0);
      expect(pointLow).toBeGreaterThan(0);
    });
  });

  describe("Mines Game", () => {
    it("should generate mine positions", () => {
      const positions = generateMinesPositions(96, 0.5);
      expect(Array.isArray(positions)).toBe(true);
      expect(positions.length).toBeGreaterThan(0);
      expect(positions.length).toBeLessThanOrEqual(25);
    });

    it("should have unique positions", () => {
      const positions = generateMinesPositions(96, 0.5);
      const unique = new Set(positions);
      expect(unique.size).toBe(positions.length);
    });

    it("should have positions within grid bounds", () => {
      const positions = generateMinesPositions(96, 0.5);
      positions.forEach((pos) => {
        expect(pos).toBeGreaterThanOrEqual(0);
        expect(pos).toBeLessThan(25);
      });
    });
  });

  describe("Plinko Game", () => {
    it("should generate valid multiplier", () => {
      const result = generatePlinkoResult(96, 0.5);
      expect(result).toBeGreaterThan(0.5);
      expect(result).toBeLessThanOrEqual(4.5);
    });
  });

  describe("Limbo Game", () => {
    it("should generate number above 1", () => {
      const num = generateLimboNumber(96, 0.5);
      expect(num).toBeGreaterThan(1);
      expect(num).toBeLessThanOrEqual(100);
    });
  });

  describe("Slot Machine", () => {
    it("should generate three reels", () => {
      const reels = generateSlotReels(96, 0.5);
      expect(reels).toHaveLength(3);
      reels.forEach((reel) => {
        expect(reel).toBeGreaterThanOrEqual(0);
        expect(reel).toBeLessThan(8);
      });
    });

    it("should calculate three-of-a-kind winnings", () => {
      const winnings = calculateSlotWinnings([0, 0, 0], 100);
      expect(winnings).toBe(1000); // 100 * 10
    });

    it("should calculate two-of-a-kind winnings", () => {
      const winnings = calculateSlotWinnings([1, 1, 2], 100);
      expect(winnings).toBe(150); // 100 * 1.5
    });

    it("should return 0 for no match", () => {
      const winnings = calculateSlotWinnings([0, 1, 2], 100);
      expect(winnings).toBe(0);
    });
  });

  describe("Color Prediction", () => {
    it("should return valid color", () => {
      const color = generateColorPredictionResult(96, 0.5);
      expect(["red", "green", "violet"]).toContain(color);
    });
  });

  describe("Agent Commission", () => {
    it("should calculate 0.5% commission", () => {
      const commission = calculateAgentCommission(10000);
      expect(commission).toBe(50); // 10000 * 0.005
    });

    it("should handle zero bets", () => {
      const commission = calculateAgentCommission(0);
      expect(commission).toBe(0);
    });

    it("should handle large amounts", () => {
      const commission = calculateAgentCommission(1000000);
      expect(commission).toBe(5000);
    });
  });

  describe("Agent Code Generation", () => {
    it("should generate unique codes", () => {
      const code1 = generateAgentCode();
      const code2 = generateAgentCode();
      expect(code1).not.toBe(code2);
    });

    it("should have correct format", () => {
      const code = generateAgentCode();
      expect(code).toMatch(/^AGENT_\d+_[A-Z0-9]+$/);
    });
  });
});
