import crypto from "crypto";

/**
 * Provably fair random number generation
 * Uses client seed, server seed, and nonce for transparent randomness
 */
export function generateServerSeed(): string {
  return crypto.randomBytes(32).toString("hex");
}

export function generateClientSeed(): string {
  return crypto.randomBytes(16).toString("hex");
}

export function generateRandomNumber(
  clientSeed: string,
  serverSeed: string,
  nonce: number,
  min: number = 0,
  max: number = 1
): number {
  const combined = `${clientSeed}:${serverSeed}:${nonce}`;
  const hash = crypto.createHmac("sha256", serverSeed).update(combined).digest();
  const randomValue = hash.readUInt32BE(0) / 0xffffffff;
  return min + randomValue * (max - min);
}

/**
 * RTP-weighted outcome calculation
 * Ensures game results respect the RTP percentage over time
 */
export function calculateRTPWeightedOutcome(
  rtp: number,
  betAmount: number,
  randomValue: number
): { won: boolean; multiplier: number } {
  const rtpThreshold = rtp / 100;

  if (randomValue < rtpThreshold) {
    // Player wins - use a bounded multiplier
    const normalizedRandom = randomValue / rtpThreshold; // 0 to 1
    const multiplier = 1.1 + normalizedRandom * 1.9; // 1.1x to 3x
    return {
      won: true,
      multiplier: Math.min(3, Math.max(1.1, multiplier)),
    };
  }

  return {
    won: false,
    multiplier: 0,
  };
}

/**
 * Aviator crash game logic
 * Multiplier increases until crash point
 */
export function generateAviatorCrashPoint(rtp: number, randomValue: number): number {
  const rtpThreshold = rtp / 100;
  if (randomValue > rtpThreshold) {
    return 1 + Math.random() * 2; // Crash between 1x and 3x
  }
  return 1 + Math.random() * 20; // Can go up to 20x
}

/**
 * Mines game logic
 * Returns positions of mines in a 5x5 grid
 */
export function generateMinesPositions(rtp: number, randomValue: number): number[] {
  const mineCount = randomValue < rtp / 100 ? 3 : 8; // Fewer mines = player advantage
  const positions: Set<number> = new Set();

  while (positions.size < mineCount) {
    positions.add(Math.floor(Math.random() * 25));
  }

  return Array.from(positions);
}

/**
 * Plinko game logic
 * Ball drops through pegs and lands in a bucket
 */
export function generatePlinkoResult(rtp: number, randomValue: number): number {
  const buckets = [0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0, 2.5, 2.0, 1.5, 1.0, 0.75, 0.5];
  const rtpThreshold = rtp / 100;

  if (randomValue < rtpThreshold) {
    // High multiplier buckets
    return buckets[Math.floor(Math.random() * buckets.length)] * 1.5;
  }

  return buckets[Math.floor(Math.random() * buckets.length)];
}

/**
 * Limbo game logic
 * Player predicts if next number will be above their target
 */
export function generateLimboNumber(rtp: number, randomValue: number): number {
  const rtpThreshold = rtp / 100;

  if (randomValue < rtpThreshold) {
    return 1.01 + Math.random() * 99.99; // Can go high
  }

  return 1.01 + Math.random() * 50; // Limited range
}

/**
 * Slot machine logic
 * Returns three reel positions
 */
export function generateSlotReels(rtp: number, randomValue: number): number[] {
  const symbols = [0, 1, 2, 3, 4, 5, 6, 7]; // 8 different symbols
  const rtpThreshold = rtp / 100;

  const reel1 = Math.floor(Math.random() * symbols.length);
  const reel2 = Math.floor(Math.random() * symbols.length);
  let reel3: number;

  if (randomValue < rtpThreshold && Math.random() < 0.3) {
    // 30% chance of winning combination if RTP allows
    reel3 = reel1; // Match first reel
  } else {
    reel3 = Math.floor(Math.random() * symbols.length);
  }

  return [reel1, reel2, reel3];
}

export function calculateSlotWinnings(reels: number[], betAmount: number): number {
  const [r1, r2, r3] = reels;

  if (r1 === r2 && r2 === r3) {
    // Three of a kind
    const multipliers: Record<number, number> = {
      0: 10, // 777
      1: 8,
      2: 6,
      3: 4,
      4: 3,
      5: 2,
      6: 1.5,
      7: 1.2,
    };
    return betAmount * (multipliers[r1] || 1);
  }

  if (r1 === r2 || r2 === r3 || r1 === r3) {
    // Two of a kind
    return betAmount * 1.5;
  }

  return 0;
}

/**
 * Card game outcomes
 */
export function generateCardGameOutcome(
  gameType: "teen_patti" | "rummy" | "andar_bahar" | "dragon_tiger",
  rtp: number,
  randomValue: number
): any {
  const rtpThreshold = rtp / 100;
  const playerWins = randomValue < rtpThreshold;

  switch (gameType) {
    case "teen_patti": {
      const playerHand = generatePokerHand();
      const dealerHand = generatePokerHand();
      return {
        playerHand,
        dealerHand,
        playerWins,
        multiplier: playerWins ? 2 : 0,
      };
    }

    case "andar_bahar": {
      const card = Math.floor(Math.random() * 13) + 1;
      const position = playerWins ? "andar" : "bahar";
      return {
        card,
        position,
        multiplier: playerWins ? 2 : 0,
      };
    }

    case "dragon_tiger": {
      const dragonCard = Math.floor(Math.random() * 13) + 1;
      const tigerCard = Math.floor(Math.random() * 13) + 1;
      const winner = playerWins ? "dragon" : "tiger";
      return {
        dragonCard,
        tigerCard,
        winner,
        multiplier: playerWins ? 2 : 0,
      };
    }

    default:
      return { playerWins, multiplier: playerWins ? 2 : 0 };
  }
}

function generatePokerHand(): string[] {
  const suits = ["♠", "♥", "♦", "♣"];
  const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
  const hand: string[] = [];

  for (let i = 0; i < 3; i++) {
    const suit = suits[Math.floor(Math.random() * suits.length)];
    const rank = ranks[Math.floor(Math.random() * ranks.length)];
    hand.push(`${rank}${suit}`);
  }

  return hand;
}

/**
 * Color prediction game (Wingo)
 */
export function generateColorPredictionResult(rtp: number, randomValue: number): string {
  const colors = ["red", "green", "violet"];
  const rtpThreshold = rtp / 100;

  if (randomValue < rtpThreshold) {
    return colors[Math.floor(Math.random() * colors.length)];
  }

  // Weighted towards less likely colors
  const weighted = Math.random();
  if (weighted < 0.4) return "red";
  if (weighted < 0.7) return "green";
  return "violet";
}

/**
 * Calculate commission for agents
 * 0.5% of total bets placed by referrals
 */
export function calculateAgentCommission(totalBetsFromDownline: number): number {
  return totalBetsFromDownline * 0.005; // 0.5%
}

/**
 * Generate unique agent code
 */
export function generateAgentCode(): string {
  return `AGENT_${Date.now()}_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}
