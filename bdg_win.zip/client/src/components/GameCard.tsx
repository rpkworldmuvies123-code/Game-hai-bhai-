import { Users } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface Game {
  id: string;
  name: string;
  category: string;
  rtp: number | string;
  minBet: string | number;
  maxBet: string | number;
  description?: string | null;
  imageUrl?: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface GameCardProps {
  game: any;
  onClick: () => void;
}

export default function GameCard({ game, onClick }: GameCardProps) {
  const { data: session } = trpc.games.getSession.useQuery({ gameId: game.id });

  return (
    <button
      onClick={onClick}
      className="game-card group"
    >
      {/* Game Image Placeholder */}
      <div className="w-full aspect-square bg-gradient-to-br from-accent/20 to-accent/5 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
        <div className="text-4xl opacity-50 group-hover:scale-110 transition-transform">
          🎮
        </div>
        {/* Corner accent */}
        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-accent" />
      </div>

      {/* Game Info */}
      <h3 className="font-bold text-sm text-foreground mb-2 line-clamp-2">
        {game.name}
      </h3>

      {/* RTP & Players */}
      <div className="flex items-center justify-between text-xs mb-2">
        <span className="text-accent font-semibold">RTP {game.rtp}%</span>
        <div className="flex items-center gap-1 text-muted-foreground">
          <Users className="w-3 h-3" />
          <span>{session?.activePlayers || 0}</span>
        </div>
      </div>

      {/* Bet Range */}
      <div className="text-xs text-muted-foreground">
        ₹{game.minBet} - ₹{game.maxBet}
      </div>
    </button>
  );
}
