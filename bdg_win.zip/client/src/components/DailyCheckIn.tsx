import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Gift } from "lucide-react";
import { toast } from "sonner";

interface DailyCheckInProps {
  lastCheckIn?: Date;
  onCheckIn?: () => void;
}

const DAILY_BONUSES = [
  { day: 1, amount: 50, bonus: "₹50 bonus" },
  { day: 2, amount: 75, bonus: "₹75 bonus" },
  { day: 3, amount: 100, bonus: "₹100 bonus" },
  { day: 4, amount: 150, bonus: "₹150 bonus" },
  { day: 5, amount: 200, bonus: "₹200 bonus" },
  { day: 6, amount: 300, bonus: "₹300 bonus" },
  { day: 7, amount: 500, bonus: "₹500 bonus + 2x multiplier" },
];

export default function DailyCheckIn({ lastCheckIn, onCheckIn }: DailyCheckInProps) {
  const [claimed, setClaimed] = useState(false);

  const canClaimToday = () => {
    if (!lastCheckIn) return true;
    const today = new Date();
    const last = new Date(lastCheckIn);
    return (
      last.getDate() !== today.getDate() ||
      last.getMonth() !== today.getMonth() ||
      last.getFullYear() !== today.getFullYear()
    );
  };

  const handleCheckIn = () => {
    if (!canClaimToday()) {
      toast.info("You already claimed today's bonus!");
      return;
    }

    setClaimed(true);
    toast.success("Daily bonus claimed! ✨");
    onCheckIn?.();
  };

  return (
    <div className="premium-card">
      <div className="flex items-center gap-3 mb-4">
        <Gift className="w-6 h-6 text-accent" />
        <h3 className="text-lg font-bold text-accent">Daily Check-in</h3>
      </div>

      {/* Bonus Days */}
      <div className="grid grid-cols-7 gap-2 mb-4">
        {DAILY_BONUSES.map((day) => (
          <div
            key={day.day}
            className="aspect-square flex flex-col items-center justify-center rounded bg-accent/10 border border-accent/30 p-1"
          >
            <p className="text-xs font-bold text-accent">Day {day.day}</p>
            <p className="text-xs text-muted-foreground">₹{day.amount}</p>
          </div>
        ))}
      </div>

      {/* Check-in Button */}
      <Button
        onClick={handleCheckIn}
        disabled={!canClaimToday() || claimed}
        className="btn-premium w-full"
      >
        {claimed
          ? "✓ Claimed Today"
          : canClaimToday()
          ? "Claim Daily Bonus"
          : "Already Claimed"}
      </Button>

      <p className="text-xs text-muted-foreground text-center mt-2">
        Claim daily to unlock bigger bonuses!
      </p>
    </div>
  );
}
