import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Spinner } from "@/components/ui/spinner";

interface DepositWithdrawModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "deposit" | "withdraw";
  onSuccess?: () => void;
}

export default function DepositWithdrawModal({
  open,
  onOpenChange,
  mode,
  onSuccess,
}: DepositWithdrawModalProps) {
  const [amount, setAmount] = useState("");
  const [bankCardNumber, setBankCardNumber] = useState("");
  const [bankName, setBankName] = useState("");
  const [cardHolderName, setCardHolderName] = useState("");

  const deposit = trpc.wallet.deposit.useMutation();
  const withdraw = trpc.wallet.requestWithdrawal.useMutation();
  const { refetch: refetchBalance } = trpc.wallet.getBalance.useQuery();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    try {
      if (mode === "deposit") {
        await deposit.mutateAsync({ amount });
        toast.success(`Deposit of ₹${amount} successful!`);
      } else {
        if (!bankCardNumber || !bankName || !cardHolderName) {
          toast.error("Please fill in all bank details");
          return;
        }
        await withdraw.mutateAsync({
          amount,
          bankCardNumber,
          bankName,
          cardHolderName,
        });
        toast.success(`Withdrawal request of ₹${amount} submitted!`);
      }

      refetchBalance();
      onSuccess?.();
      onOpenChange(false);
      setAmount("");
      setBankCardNumber("");
      setBankName("");
      setCardHolderName("");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Operation failed");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-md">
        <DialogHeader>
          <DialogTitle className="text-accent">
            {mode === "deposit" ? "Deposit Funds" : "Withdraw Funds"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Amount */}
          <div>
            <label className="text-xs text-muted-foreground">Amount (₹)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              className="w-full bg-input text-input-foreground px-3 py-2 rounded mt-1"
              step="0.01"
              min="0"
            />
            {mode === "withdraw" && (
              <p className="text-xs text-muted-foreground mt-1">
                Min: ₹1000 | Max: ₹99999
              </p>
            )}
          </div>

          {/* Withdrawal-specific fields */}
          {mode === "withdraw" && (
            <>
              <div>
                <label className="text-xs text-muted-foreground">Card Number</label>
                <input
                  type="text"
                  value={bankCardNumber}
                  onChange={(e) => setBankCardNumber(e.target.value)}
                  placeholder="Enter card number"
                  className="w-full bg-input text-input-foreground px-3 py-2 rounded mt-1"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="e.g., HDFC Bank"
                  className="w-full bg-input text-input-foreground px-3 py-2 rounded mt-1"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground">Card Holder Name</label>
                <input
                  type="text"
                  value={cardHolderName}
                  onChange={(e) => setCardHolderName(e.target.value)}
                  placeholder="Name on card"
                  className="w-full bg-input text-input-foreground px-3 py-2 rounded mt-1"
                />
              </div>
            </>
          )}

          {/* Buttons */}
          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={deposit.isPending || withdraw.isPending}
              className="btn-premium flex-1"
            >
              {deposit.isPending || withdraw.isPending ? (
                <>
                  <Spinner className="w-4 h-4 mr-2" />
                  Processing...
                </>
              ) : (
                `${mode === "deposit" ? "Deposit" : "Withdraw"}`
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
