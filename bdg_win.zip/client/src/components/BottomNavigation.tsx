import { useLocation } from "wouter";
import { Home, Activity, Gift, User, Settings } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function BottomNavigation() {
  const [location, navigate] = useLocation();
  const { user } = useAuth();

  const isActive = (path: string) => location === path;

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/activity", label: "Activity", icon: Activity },
    { path: "/promotions", label: "Promotions", icon: Gift },
    { path: "/account", label: "Account", icon: User },
    ...(user?.role === "admin" ? [{ path: "/admin", label: "Admin", icon: Settings }] : []),
  ];

  return (
    <nav className="bottom-nav">
      {navItems.map(({ path, label, icon: Icon }) => (
        <button
          key={path}
          onClick={() => navigate(path)}
          className={`nav-item ${isActive(path) ? "active" : ""}`}
          title={label}
        >
          <Icon className="w-6 h-6" />
          <span className="text-xs mt-1">{label}</span>
        </button>
      ))}
    </nav>
  );
}
