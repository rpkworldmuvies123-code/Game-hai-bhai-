import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface MinesGameProps {
  betId: string;
  betAmount: string;
  serverSeed: string;
  onResult: (won: boolean, multiplier: number) => void;
}

export default function MinesGame({
  betId,
  betAmount,
  serverSeed,
  onResult,
}: MinesGameProps) {
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [gameState, setGameState] = useState<"playing" | "won" | "lost">("playing");
  const [multiplier, setMultiplier] = useState(1.0);

  // Initialize game
  useEffect(() => {
    // Generate mine positions from server seed
    const seed = parseInt(serverSeed.substring(0, 8), 16);
    const mines: number[] = [];
    const used = new Set<number>();

    // Place 5 mines randomly
    for (let i = 0; i < 5; i++) {
      let pos = (seed + i * 1000) % 25;
      while (used.has(pos)) {
        pos = (pos + 1) % 25;
      }
      mines.push(pos);
      used.add(pos);
    }

    setMinePositions(mines);
  }, [serverSeed]);

  const handleReveal = (index: number) => {
    if (gameState !== "playing" || revealed.has(index)) return;

    const newRevealed = new Set(revealed);
    newRevealed.add(index);
    setRevealed(newRevealed);

    if (minePositions.includes(index)) {
      // Hit a mine - game over
      setGameState("lost");
      onResult(false, 0);
    } else {
      // Safe - increase multiplier
      const newMultiplier = 1 + newRevealed.size * 0.2;
      setMultiplier(newMultiplier);

      // Check if all safe tiles revealed
      if (newRevealed.size === 20) {
        setGameState("won");
        onResult(true, newMultiplier);
      }
    }
  };

  const handleCashOut = () => {
    setGameState("won");
    onResult(true, multiplier);
  };

  const handleReset = () => {
    setRevealed(new Set());
    setGameState("playing");
    setMultiplier(1.0);
  };

  return (
    <div className="space-y-4">
      {/* Game Display */}
      <div className="premium-card p-4">
        <div className="grid grid-cols-5 gap-2 mb-4">
          {Array.from({ length: 25 }).map((_, index) => (
            <button
              key={index}
              onClick={() => handleReveal(index)}
              disabled={gameState !== "playing" || revealed.has(index)}
              className={`aspect-square rounded font-bold text-sm transition ${
                revealed.has(index)
                  ? minePositions.includes(index)
                    ? "bg-red-500 text-white"
                    : "bg-green-500 text-white"
                  : "bg-accent/30 hover:bg-accent/50 disabled:opacity-50"
              }`}
            >
              {revealed.has(index) && (minePositions.includes(index) ? "💣" : "⭐")}
            </button>
          ))}
        </div>

        {/* Status */}
        <div className="text-center">
          {gameState === "playing" && (
            <p className="text-muted-foreground">
              Revealed: {revealed.size}/20 | Multiplier: {multiplier.toFixed(2)}x
            </p>
          )}
          {gameState === "won" && (
            <p className="text-green-500 font-bold">✓ You Won! {multiplier.toFixed(2)}x</p>
          )}
          {gameState === "lost" && (
            <p className="text-red-500 font-bold">✗ You Hit a Mine!</p>
          )}
        </div>
      </div>

      {/* Bet Info */}
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Bet</p>
          <p className="font-bold text-accent">₹{betAmount}</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Potential Win</p>
          <p className="font-bold text-green-500">
            ₹{(parseFloat(betAmount) * multiplier).toFixed(2)}
          </p>
        </div>
      </div>

      {/* Controls */}
      {gameState === "playing" && (
        <Button onClick={handleCashOut} className="btn-premium w-full">
          Cash Out {multiplier.toFixed(2)}x
        </Button>
      )}

      {gameState !== "playing" && (
        <Button onClick={handleReset} className="btn-premium w-full">
          Play Again
        </Button>
      )}
    </div>
  );
}
