import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";

interface AviatorGameProps {
  betId: string;
  betAmount: string;
  serverSeed: string;
  onResult: (won: boolean, multiplier: number) => void;
}

export default function AviatorGame({
  betId,
  betAmount,
  serverSeed,
  onResult,
}: AviatorGameProps) {
  const [multiplier, setMultiplier] = useState(1.0);
  const [gameState, setGameState] = useState<"waiting" | "flying" | "crashed">("waiting");
  const [crashPoint, setCrashPoint] = useState(0);
  const [cashOutMultiplier, setCashOutMultiplier] = useState<number | null>(null);

  // Simulate game
  useEffect(() => {
    if (gameState !== "flying") return;

    // Generate crash point based on server seed
    const seed = parseInt(serverSeed.substring(0, 8), 16);
    const crash = 1 + (seed % 1000) / 100; // 1.0 to 11.0

    setCrashPoint(crash);

    const interval = setInterval(() => {
      setMultiplier((prev) => {
        const newMultiplier = prev + 0.01;
        if (newMultiplier >= crash) {
          setGameState("crashed");
          onResult(false, 0);
          return crash;
        }
        return newMultiplier;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [gameState, serverSeed, onResult]);

  const handleStart = () => {
    setGameState("flying");
    setMultiplier(1.0);
    setCashOutMultiplier(null);
  };

  const handleCashOut = () => {
    setGameState("crashed");
    setCashOutMultiplier(multiplier);
    onResult(true, multiplier);
  };

  return (
    <div className="space-y-4">
      {/* Game Display */}
      <div className="premium-card h-64 flex flex-col items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-accent/5 to-transparent" />

        {gameState === "waiting" && (
          <div className="text-center">
            <p className="text-4xl font-bold text-accent mb-2">✈️</p>
            <p className="text-muted-foreground">Ready to fly?</p>
          </div>
        )}

        {gameState === "flying" && (
          <div className="text-center">
            <p className="text-6xl font-bold text-accent animate-pulse">
              {multiplier.toFixed(2)}x
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Crash at {crashPoint.toFixed(2)}x
            </p>
          </div>
        )}

        {gameState === "crashed" && (
          <div className="text-center">
            <p className="text-4xl font-bold text-red-500 mb-2">💥</p>
            <p className="text-muted-foreground">
              {cashOutMultiplier
                ? `You cashed out at ${cashOutMultiplier.toFixed(2)}x`
                : `Crashed at ${crashPoint.toFixed(2)}x`}
            </p>
          </div>
        )}
      </div>

      {/* Bet Info */}
      <div className="grid grid-cols-3 gap-2 text-sm">
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Bet</p>
          <p className="font-bold text-accent">₹{betAmount}</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Multiplier</p>
          <p className="font-bold">{multiplier.toFixed(2)}x</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Potential Win</p>
          <p className="font-bold text-green-500">
            ₹{(parseFloat(betAmount) * multiplier).toFixed(2)}
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-2">
        {gameState === "waiting" && (
          <Button onClick={handleStart} className="btn-premium flex-1">
            Start Game
          </Button>
        )}

        {gameState === "flying" && (
          <Button onClick={handleCashOut} className="btn-premium flex-1">
            Cash Out at {multiplier.toFixed(2)}x
          </Button>
        )}

        {gameState === "crashed" && (
          <Button disabled className="flex-1">
            Game Over
          </Button>
        )}
      </div>
    </div>
  );
}
