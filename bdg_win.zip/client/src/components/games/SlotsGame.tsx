import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface SlotsGameProps {
  betId: string;
  betAmount: string;
  serverSeed: string;
  onResult: (won: boolean, multiplier: number) => void;
}

const SYMBOLS = ["🍎", "🍊", "🍋", "🍌", "🍉", "🍓", "🎰", "💎"];

export default function SlotsGame({
  betId,
  betAmount,
  serverSeed,
  onResult,
}: SlotsGameProps) {
  const [reels, setReels] = useState<string[]>(["🎰", "🎰", "🎰"]);
  const [gameState, setGameState] = useState<"ready" | "spinning" | "result">("ready");
  const [multiplier, setMultiplier] = useState(0);

  const handleSpin = () => {
    setGameState("spinning");

    // Spin animation
    let spins = 0;
    const spinInterval = setInterval(() => {
      const seed = parseInt(serverSeed.substring(0, 8), 16);
      setReels([
        SYMBOLS[(seed + spins) % SYMBOLS.length],
        SYMBOLS[(seed + spins + 1) % SYMBOLS.length],
        SYMBOLS[(seed + spins + 2) % SYMBOLS.length],
      ]);
      spins++;

      if (spins > 20) {
        clearInterval(spinInterval);

        // Generate final result
        const seed = parseInt(serverSeed.substring(0, 8), 16);
        const finalReels = [
          SYMBOLS[seed % SYMBOLS.length],
          SYMBOLS[(seed + 1) % SYMBOLS.length],
          SYMBOLS[(seed + 2) % SYMBOLS.length],
        ];
        setReels(finalReels);

        // Calculate win
        let winMultiplier = 0;
        if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
          winMultiplier = 10; // Three of a kind
        } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2]) {
          winMultiplier = 1.5; // Two of a kind
        }

        setMultiplier(winMultiplier);
        setGameState("result");
        onResult(winMultiplier > 0, winMultiplier);
      }
    }, 50);
  };

  const handlePlayAgain = () => {
    setGameState("ready");
    setReels(["🎰", "🎰", "🎰"]);
    setMultiplier(0);
  };

  return (
    <div className="space-y-4">
      {/* Game Display */}
      <div className="premium-card p-8">
        <div className="flex justify-center gap-4 mb-6">
          {reels.map((symbol, index) => (
            <div
              key={index}
              className={`w-20 h-20 flex items-center justify-center text-5xl rounded border-2 border-accent/50 ${
                gameState === "spinning" ? "animate-bounce" : ""
              }`}
            >
              {symbol}
            </div>
          ))}
        </div>

        {/* Result */}
        {gameState === "result" && (
          <div className="text-center">
            {multiplier > 0 ? (
              <div>
                <p className="text-2xl font-bold text-green-500 mb-2">🎉 You Won!</p>
                <p className="text-xl font-bold text-accent">{multiplier}x Multiplier</p>
              </div>
            ) : (
              <p className="text-xl font-bold text-red-500">Try Again</p>
            )}
          </div>
        )}
      </div>

      {/* Bet Info */}
      <div className="grid grid-cols-3 gap-2 text-sm">
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Bet</p>
          <p className="font-bold text-accent">₹{betAmount}</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Multiplier</p>
          <p className="font-bold">{multiplier}x</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Win</p>
          <p className="font-bold text-green-500">
            ₹{(parseFloat(betAmount) * multiplier).toFixed(2)}
          </p>
        </div>
      </div>

      {/* Controls */}
      {gameState === "ready" && (
        <Button onClick={handleSpin} className="btn-premium w-full">
          Spin Reels
        </Button>
      )}

      {gameState === "spinning" && (
        <Button disabled className="w-full">
          Spinning...
        </Button>
      )}

      {gameState === "result" && (
        <Button onClick={handlePlayAgain} className="btn-premium w-full">
          Play Again
        </Button>
      )}
    </div>
  );
}
