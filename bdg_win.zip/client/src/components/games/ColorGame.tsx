import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface ColorGameProps {
  betId: string;
  betAmount: string;
  serverSeed: string;
  onResult: (won: boolean, multiplier: number) => void;
}

const COLORS = [
  { name: "Red", value: "red", odds: 2 },
  { name: "Green", value: "green", odds: 2 },
  { name: "Violet", value: "violet", odds: 3 },
];

export default function ColorGame({
  betId,
  betAmount,
  serverSeed,
  onResult,
}: ColorGameProps) {
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [resultColor, setResultColor] = useState<string | null>(null);
  const [gameState, setGameState] = useState<"selecting" | "spinning" | "result">("selecting");
  const [countdown, setCountdown] = useState(5);

  // Generate result
  useEffect(() => {
    if (gameState !== "spinning") return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Generate result
          const seed = parseInt(serverSeed.substring(0, 8), 16);
          const colorIndex = seed % 3;
          const result = COLORS[colorIndex].value;
          setResultColor(result);
          setGameState("result");

          // Determine win/loss
          const won = result === selectedColor;
          const selectedColorData = COLORS.find((c) => c.value === selectedColor);
          const multiplier = selectedColorData?.odds || 2;
          onResult(won, won ? multiplier : 0);

          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, serverSeed, selectedColor, onResult]);

  const handleSelectColor = (color: string) => {
    if (gameState === "selecting") {
      setSelectedColor(color);
      setGameState("spinning");
      setCountdown(5);
    }
  };

  const getColorBg = (color: string) => {
    switch (color) {
      case "red":
        return "bg-red-500";
      case "green":
        return "bg-green-500";
      case "violet":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-4">
      {/* Game Display */}
      <div className="premium-card h-64 flex flex-col items-center justify-center">
        {gameState === "selecting" && (
          <div className="text-center">
            <p className="text-2xl font-bold text-accent mb-4">Predict the Color</p>
            <p className="text-muted-foreground">Select a color below</p>
          </div>
        )}

        {gameState === "spinning" && (
          <div className="text-center">
            <p className="text-6xl font-bold text-accent animate-pulse mb-2">🎡</p>
            <p className="text-2xl font-bold">Spinning...</p>
            <p className="text-4xl font-bold text-accent mt-4">{countdown}s</p>
          </div>
        )}

        {gameState === "result" && (
          <div className="text-center">
            <div className={`w-32 h-32 rounded-full ${getColorBg(resultColor || "")} mx-auto mb-4`} />
            <p className="text-2xl font-bold capitalize">{resultColor}</p>
            <p className="text-lg font-bold text-green-500 mt-2">
              {resultColor === selectedColor ? "✓ You Won!" : "✗ You Lost"}
            </p>
          </div>
        )}
      </div>

      {/* Color Selection */}
      {gameState === "selecting" && (
        <div className="grid grid-cols-3 gap-2">
          {COLORS.map((color) => (
            <Button
              key={color.value}
              onClick={() => handleSelectColor(color.value)}
              className={`h-20 font-bold text-white ${getColorBg(color.value)}`}
            >
              <div className="text-center">
                <p>{color.name}</p>
                <p className="text-xs">{color.odds}x</p>
              </div>
            </Button>
          ))}
        </div>
      )}

      {/* Bet Info */}
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Bet</p>
          <p className="font-bold text-accent">₹{betAmount}</p>
        </div>
        <div className="premium-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Selected</p>
          <p className="font-bold capitalize">{selectedColor || "-"}</p>
        </div>
      </div>
    </div>
  );
}
