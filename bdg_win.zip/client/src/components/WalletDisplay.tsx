import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import { useState } from "react";
import DepositWithdrawModal from "./DepositWithdrawModal";

export default function WalletDisplay() {
  const { data: wallet, isLoading, refetch } = trpc.wallet.getBalance.useQuery();
  const claimBonus = trpc.wallet.claimWelcomeBonus.useMutation();
  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);

  const handleClaimBonus = async () => {
    try {
      await claimBonus.mutateAsync();
      toast.success("₹500 bonus claimed successfully!");
      refetch();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to claim bonus");
    }
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-4">
      {/* Balance Display */}
      <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-lg p-4 border border-accent/30">
        <p className="text-xs text-muted-foreground mb-1">Current Balance</p>
        <p className="text-3xl font-bold text-accent">
          ₹{parseFloat(wallet?.balance || "0").toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-2">
          Total Deposited: ₹{parseFloat(wallet?.totalDeposited || "0").toFixed(2)}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          variant="outline"
          className="text-sm"
          onClick={() => setDepositOpen(true)}
        >
          Deposit
        </Button>
        <Button
          variant="outline"
          className="text-sm"
          onClick={() => setWithdrawOpen(true)}
        >
          Withdraw
        </Button>
      </div>

      {/* Welcome Bonus Button */}
      {!wallet?.receivedWelcomeBonus && (
        <Button
          onClick={handleClaimBonus}
          disabled={claimBonus.isPending}
          className="btn-premium w-full"
        >
          {claimBonus.isPending ? (
            <Spinner className="w-4 h-4 mr-2" />
          ) : null}
          Get ₹500 bonus
        </Button>
      )}

      {/* Bonus Claimed */}
      {wallet?.receivedWelcomeBonus && (
        <div className="text-center text-xs text-green-500">
          ✓ Welcome bonus claimed
        </div>
      )}

      {/* VIP Level */}
      {wallet?.vipLevel && wallet.vipLevel > 0 && (
        <div className="text-center text-xs text-accent">
          VIP Level {wallet.vipLevel}
        </div>
      )}

      {/* Modals */}
      <DepositWithdrawModal
        open={depositOpen}
        onOpenChange={setDepositOpen}
        mode="deposit"
        onSuccess={() => refetch()}
      />
      <DepositWithdrawModal
        open={withdrawOpen}
        onOpenChange={setWithdrawOpen}
        mode="withdraw"
        onSuccess={() => refetch()}
      />
    </div>
  );
}
