import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { Gift } from "lucide-react";

export default function Promotions() {
  const { data: promotions, isLoading } = trpc.promotions.getAll.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <h1 className="text-3xl font-bold text-accent mb-6 art-deco-top">Promotions</h1>

      <div className="space-y-3">
        {promotions && promotions.length > 0 ? (
          promotions.map((promo) => (
            <div key={promo.id} className="premium-card">
              <div className="flex gap-3">
                <Gift className="w-6 h-6 text-accent flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{promo.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {promo.description}
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-accent font-bold">
                      ₹{parseFloat(promo.bonusAmount).toFixed(2)}
                    </span>
                    <span className="text-xs text-muted-foreground capitalize">
                      {promo.bonusType.replace("_", " ")}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No active promotions</p>
          </div>
        )}
      </div>
    </div>
  );
}
