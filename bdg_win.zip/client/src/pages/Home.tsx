import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import GameCard from "@/components/GameCard";
import WalletDisplay from "@/components/WalletDisplay";
import DailyCheckIn from "@/components/DailyCheckIn";

interface Game {
  id: string;
  name: string;
  category: string;
  rtp: number | string;
  minBet: string | number;
  maxBet: string | number;
  description?: string | null;
  imageUrl?: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const CATEGORIES = [
  { id: "arcade_crash", label: "Arcade/Crash" },
  { id: "card_games", label: "Card Games" },
  { id: "slots", label: "Slots" },
  { id: "lottery", label: "Lottery" },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { data: allGames, isLoading } = trpc.games.getAll.useQuery();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
        <div className="text-center space-y-6">
          <h1 className="text-5xl font-bold text-accent">BDG Win</h1>
          <p className="text-xl text-muted-foreground">
            Premium Gaming Platform for India
          </p>
          <p className="text-sm text-muted-foreground max-w-md">
            Experience cinematic luxury with real-money games, instant payouts, and exclusive rewards.
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="btn-premium"
          >
            Login to Play
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Wallet Section */}
      <div className="px-4 mb-4 mt-4">
        <WalletDisplay />
      </div>

      {/* Daily Check-in */}
      <div className="px-4 mb-6">
        <DailyCheckIn />
      </div>

      {/* Game Categories */}
      <div className="px-4 space-y-8">
        {CATEGORIES.map((category) => {
          const categoryGames = (allGames as Game[] | undefined)?.filter(
            (g) => g.category === category.id
          ) || [];

          if (categoryGames.length === 0) return null;

          return (
            <div key={category.id} className="space-y-3">
              <h2 className="text-2xl font-bold text-accent art-deco-top">
                {category.label}
              </h2>

              <div className="grid grid-cols-2 gap-3">
                {categoryGames.map((game: Game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    onClick={() => navigate(`/game/${game.id}`)}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
