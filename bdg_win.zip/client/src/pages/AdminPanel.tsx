import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function AdminPanel() {
  const { user } = useAuth();
  const { data: withdrawals, isLoading, refetch } = trpc.admin.getPendingWithdrawals.useQuery();
  const approveWithdrawal = trpc.admin.approveWithdrawal.useMutation();
  const rejectWithdrawal = trpc.admin.rejectWithdrawal.useMutation();

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Access denied. Admin only.</p>
      </div>
    );
  }

  const handleApprove = async (requestId: number) => {
    try {
      await approveWithdrawal.mutateAsync({ requestId });
      toast.success("Withdrawal approved");
      refetch();
    } catch (error) {
      toast.error("Failed to approve withdrawal");
    }
  };

  const handleReject = async (requestId: number) => {
    try {
      await rejectWithdrawal.mutateAsync({
        requestId,
        reason: "Rejected by admin",
      });
      toast.success("Withdrawal rejected");
      refetch();
    } catch (error) {
      toast.error("Failed to reject withdrawal");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <h1 className="text-3xl font-bold text-accent mb-6 art-deco-top">Admin Panel</h1>

      {/* Pending Withdrawals */}
      <div className="premium-card mb-6">
        <h2 className="text-xl font-bold text-accent mb-4">
          Pending Withdrawals ({withdrawals?.length || 0})
        </h2>

        {withdrawals && withdrawals.length > 0 ? (
          <div className="space-y-3">
            {withdrawals.map((wr) => (
              <div key={wr.id} className="border border-accent/30 rounded p-3">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">₹{parseFloat(wr.amount).toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">
                      {wr.cardHolderName} - {wr.bankName}
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(wr.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => handleApprove(wr.id)}
                    disabled={approveWithdrawal.isPending}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleReject(wr.id)}
                    disabled={rejectWithdrawal.isPending}
                  >
                    Reject
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">No pending withdrawals</p>
        )}
      </div>
    </div>
  );
}
