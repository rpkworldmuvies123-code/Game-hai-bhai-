import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";

export default function GameDetail() {
  const [match, params] = useRoute("/game/:gameId");
  const [, navigate] = useLocation();
  const gameId = params?.gameId as string;

  const { data: game, isLoading: gameLoading } = trpc.games.getAll.useQuery();
  const { data: wallet } = trpc.wallet.getBalance.useQuery();
  const placeBet = trpc.bets.placeBet.useMutation();

  const [betAmount, setBetAmount] = useState("100");

  const currentGame = game?.find((g) => g.id === gameId);

  if (gameLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (!currentGame) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Game not found</p>
      </div>
    );
  }

  const handlePlaceBet = async () => {
    try {
      const amount = parseFloat(betAmount);
      const balance = parseFloat(wallet?.balance || "0");

      if (amount < parseFloat(currentGame.minBet)) {
        toast.error(`Minimum bet is ₹${currentGame.minBet}`);
        return;
      }

      if (amount > parseFloat(currentGame.maxBet)) {
        toast.error(`Maximum bet is ₹${currentGame.maxBet}`);
        return;
      }

      if (amount > balance) {
        toast.error("Insufficient balance");
        return;
      }

      const result = await placeBet.mutateAsync({
        gameId,
        betAmount: amount.toFixed(2),
        clientSeed: Math.random().toString(36).substring(2),
      });

      toast.success("Bet placed! Game starting...");
      // In a real game, this would trigger the game UI
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to place bet");
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/")}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-3xl font-bold text-accent">{currentGame.name}</h1>
      </div>

      {/* Game Info */}
      <div className="premium-card mb-6">
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div>
            <p className="text-xs text-muted-foreground">RTP</p>
            <p className="text-lg font-bold text-accent">{currentGame.rtp}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Min Bet</p>
            <p className="text-lg font-bold">₹{currentGame.minBet}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Max Bet</p>
            <p className="text-lg font-bold">₹{currentGame.maxBet}</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          {currentGame.description || "Experience premium gaming with provably fair outcomes."}
        </p>
      </div>

      {/* Game Area Placeholder */}
      <div className="premium-card mb-6 h-64 flex items-center justify-center">
        <p className="text-muted-foreground text-center">
          Game interface coming soon<br />
          <span className="text-2xl mt-4 block">🎮</span>
        </p>
      </div>

      {/* Betting Section */}
      <div className="premium-card mb-6">
        <h2 className="text-lg font-bold text-accent mb-4">Place Your Bet</h2>

        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Bet Amount</p>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              className="flex-1 bg-input text-input-foreground px-3 py-2 rounded"
              min={currentGame.minBet}
              max={currentGame.maxBet}
            />
            <span className="flex items-center text-accent font-bold">₹</span>
          </div>
        </div>

        <div className="mb-4 p-3 bg-accent/10 rounded">
          <p className="text-xs text-muted-foreground">Your Balance</p>
          <p className="text-xl font-bold text-accent">
            ₹{parseFloat(wallet?.balance || "0").toFixed(2)}
          </p>
        </div>

        <Button
          onClick={handlePlaceBet}
          disabled={placeBet.isPending}
          className="btn-premium w-full"
        >
          {placeBet.isPending ? "Processing..." : "Place Bet"}
        </Button>
      </div>
    </div>
  );
}
