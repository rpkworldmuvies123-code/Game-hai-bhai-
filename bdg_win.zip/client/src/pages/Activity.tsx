import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";

export default function Activity() {
  const { data: transactions, isLoading } = trpc.wallet.getTransactions.useQuery({
    limit: 100,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <h1 className="text-3xl font-bold text-accent mb-6 art-deco-top">Activity</h1>

      <div className="space-y-3">
        {transactions && transactions.length > 0 ? (
          transactions.map((tx) => (
            <div key={tx.id} className="premium-card">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold text-foreground capitalize">
                    {tx.type}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(tx.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${
                    tx.type === "deposit" || tx.type === "win" || tx.type === "bonus"
                      ? "text-green-500"
                      : "text-red-500"
                  }`}>
                    {tx.type === "deposit" || tx.type === "win" || tx.type === "bonus" ? "+" : "-"}
                    ₹{parseFloat(tx.amount).toFixed(2)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Balance: ₹{parseFloat(tx.balanceAfter).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No transactions yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
