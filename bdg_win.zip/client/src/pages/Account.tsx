import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { Copy, LogOut } from "lucide-react";
import { toast } from "sonner";

export default function Account() {
  const { user, logout } = useAuth();
  const getAgentCode = trpc.agent.getOrCreateCode.useMutation();
  const { data: agentData, isLoading: agentLoading } = trpc.agent.getReferrals.useQuery();
  const { data: commissions } = trpc.agent.getTotalCommissions.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    logout();
  };

  const handleGetAgentCode = async () => {
    try {
      const result = await getAgentCode.mutateAsync();
      toast.success("Agent code generated!");
    } catch (error) {
      toast.error("Failed to generate agent code");
    }
  };

  const copyAgentCode = () => {
    if (getAgentCode.data?.agentCode) {
      navigator.clipboard.writeText(getAgentCode.data.agentCode);
      toast.success("Agent code copied!");
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <h1 className="text-3xl font-bold text-accent mb-6 art-deco-top">Account</h1>

      {/* Profile Section */}
      <div className="premium-card mb-6">
        <h2 className="text-xl font-bold text-accent mb-4">Profile</h2>
        <div className="space-y-3">
          <div>
            <p className="text-xs text-muted-foreground">Name</p>
            <p className="font-semibold">{user?.name || "N/A"}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Email</p>
            <p className="font-semibold">{user?.email || "N/A"}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Role</p>
            <p className="font-semibold capitalize">{user?.role || "User"}</p>
          </div>
          {user?.vipLevel && user.vipLevel > 0 && (
            <div>
              <p className="text-xs text-muted-foreground">VIP Level</p>
              <p className="font-semibold text-accent">{user.vipLevel}</p>
            </div>
          )}
        </div>
      </div>

      {/* Agent Section */}
      {user?.isAgent && (
        <div className="premium-card mb-6">
          <h2 className="text-xl font-bold text-accent mb-4">Agent Dashboard</h2>
          {agentLoading ? (
            <Spinner />
          ) : (
            <div className="space-y-3">
              <Button
                onClick={handleGetAgentCode}
                disabled={getAgentCode.isPending}
                className="btn-premium w-full"
              >
                {getAgentCode.isPending ? "Generating..." : "Generate Agent Code"}
              </Button>
              {getAgentCode.data?.agentCode && (
                <>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Your Agent Code</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={getAgentCode.data.agentCode}
                        readOnly
                        className="flex-1 bg-input text-input-foreground px-3 py-2 rounded text-sm"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={copyAgentCode}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Commission Earned</p>
                    <p className="text-2xl font-bold text-accent">
                      ₹{parseFloat(commissions?.totalCommissionEarned || "0").toFixed(2)}
                    </p>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Apply as Agent */}
      {!user?.isAgent && (
        <Button className="btn-premium w-full mb-6">
          Become an Agent
        </Button>
      )}

      {/* Logout */}
      <Button
        onClick={handleLogout}
        disabled={logoutMutation.isPending}
        variant="outline"
        className="w-full"
      >
        <LogOut className="w-4 h-4 mr-2" />
        {logoutMutation.isPending ? "Logging out..." : "Logout"}
      </Button>
    </div>
  );
}
