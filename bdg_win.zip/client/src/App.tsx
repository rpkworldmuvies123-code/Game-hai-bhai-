import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Activity from "./pages/Activity";
import Promotions from "./pages/Promotions";
import Account from "./pages/Account";
import AdminPanel from "./pages/AdminPanel";
import GameDetail from "./pages/GameDetail";
import BottomNavigation from "./components/BottomNavigation";
import { useAuth } from "./_core/hooks/useAuth";
import { Spinner } from "./components/ui/spinner";

function Router() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="pb-24">
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/activity"} component={Activity} />
        <Route path={"/promotions"} component={Promotions} />
        <Route path={"/account"} component={Account} />
        <Route path={"/admin"} component={AdminPanel} />
        <Route path={"/game/:gameId"} component={GameDetail} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
      <BottomNavigation />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
