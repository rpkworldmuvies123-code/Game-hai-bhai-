CREATE TABLE `bets` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`gameId` varchar(64) NOT NULL,
	`betAmount` decimal(15,2) NOT NULL,
	`resultAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`status` enum('pending','won','lost','cancelled') NOT NULL DEFAULT 'pending',
	`gameData` json,
	`resultData` json,
	`clientSeed` varchar(255),
	`serverSeed` varchar(255),
	`nonce` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` datetime,
	CONSTRAINT `bets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dailyCheckIns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`checkInDate` varchar(10) NOT NULL,
	`bonusAmount` decimal(15,2) NOT NULL,
	`streakDays` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `dailyCheckIns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dailyCommissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agentUserId` int NOT NULL,
	`commissionDate` varchar(10) NOT NULL,
	`totalBetsFromDownline` decimal(15,2) NOT NULL DEFAULT '0',
	`commissionAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`status` enum('pending','credited') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyCommissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameResultOverrides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`betId` varchar(64) NOT NULL,
	`originalResult` json,
	`overrideResult` json NOT NULL,
	`reason` text,
	`adminUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gameResultOverrides_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameSessions` (
	`id` varchar(64) NOT NULL,
	`gameId` varchar(64) NOT NULL,
	`activePlayers` int NOT NULL DEFAULT 0,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `games` (
	`id` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('arcade_crash','card_games','slots','lottery') NOT NULL,
	`rtp` decimal(5,2) NOT NULL,
	`minBet` decimal(15,2) NOT NULL DEFAULT '10',
	`maxBet` decimal(15,2) NOT NULL DEFAULT '10000',
	`description` text,
	`imageUrl` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `games_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `promotions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`bonusAmount` decimal(15,2) NOT NULL,
	`bonusType` enum('deposit_match','free_bet','cashback','reload') NOT NULL,
	`minDepositRequired` decimal(15,2) DEFAULT '0',
	`maxBonusAmount` decimal(15,2),
	`wagering_multiplier` int DEFAULT 1,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `promotions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agentUserId` int NOT NULL,
	`referredUserId` int NOT NULL,
	`level` int NOT NULL DEFAULT 1,
	`totalBetsFromReferral` decimal(15,2) NOT NULL DEFAULT '0',
	`commissionEarned` decimal(15,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('deposit','withdrawal','bet','win','bonus','commission') NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`balanceBefore` decimal(15,2) NOT NULL,
	`balanceAfter` decimal(15,2) NOT NULL,
	`status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'completed',
	`gameId` varchar(64),
	`betId` varchar(64),
	`withdrawalRequestId` int,
	`description` text,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawalRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`bankCardNumber` text,
	`bankName` varchar(255),
	`cardHolderName` varchar(255),
	`status` enum('pending','approved','rejected','completed') NOT NULL DEFAULT 'pending',
	`approvedBy` int,
	`approvalNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `withdrawalRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','agent','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(15,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalDeposited` decimal(15,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWithdrawn` decimal(15,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `receivedWelcomeBonus` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `vipLevel` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalBetsPlaced` decimal(15,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `isAgent` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `agentCode` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `referredBy` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `totalCommissionEarned` decimal(15,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `bankCardNumber` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bankName` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `cardHolderName` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_agentCode_unique` UNIQUE(`agentCode`);