import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
  datetime,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with gaming-specific fields for wallet, agent status, and VIP level.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "agent", "admin"]).default("user").notNull(),
  
  // Wallet & Balance
  balance: decimal("balance", { precision: 15, scale: 2 }).default("0").notNull(),
  totalDeposited: decimal("totalDeposited", { precision: 15, scale: 2 }).default("0").notNull(),
  totalWithdrawn: decimal("totalWithdrawn", { precision: 15, scale: 2 }).default("0").notNull(),
  
  // Bonus & Incentives
  receivedWelcomeBonus: boolean("receivedWelcomeBonus").default(false).notNull(),
  vipLevel: int("vipLevel").default(0).notNull(),
  totalBetsPlaced: decimal("totalBetsPlaced", { precision: 15, scale: 2 }).default("0").notNull(),
  
  // Agent System
  isAgent: boolean("isAgent").default(false).notNull(),
  agentCode: varchar("agentCode", { length: 32 }).unique(),
  referredBy: varchar("referredBy", { length: 32 }), // Agent code of referrer
  totalCommissionEarned: decimal("totalCommissionEarned", { precision: 15, scale: 2 }).default("0").notNull(),
  
  // Bank Card Info for Withdrawals
  bankCardNumber: text("bankCardNumber"), // Encrypted
  bankName: varchar("bankName", { length: 255 }),
  cardHolderName: varchar("cardHolderName", { length: 255 }),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Wallet transactions (deposits, withdrawals, bets, wins, bonuses)
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "bonus", "commission"]).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  balanceBefore: decimal("balanceBefore", { precision: 15, scale: 2 }).notNull(),
  balanceAfter: decimal("balanceAfter", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "cancelled"]).default("completed").notNull(),
  
  // Game-related
  gameId: varchar("gameId", { length: 64 }),
  betId: varchar("betId", { length: 64 }),
  
  // Withdrawal-specific
  withdrawalRequestId: int("withdrawalRequestId"),
  
  description: text("description"),
  metadata: json("metadata"), // Store additional data like game details
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Withdrawal requests awaiting approval
 */
export const withdrawalRequests = mysqlTable("withdrawalRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  bankCardNumber: text("bankCardNumber"), // Encrypted
  bankName: varchar("bankName", { length: 255 }),
  cardHolderName: varchar("cardHolderName", { length: 255 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "completed"]).default("pending").notNull(),
  
  approvedBy: int("approvedBy"), // Admin user ID
  approvalNotes: text("approvalNotes"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = typeof withdrawalRequests.$inferInsert;

/**
 * Game definitions with RTP and metadata
 */
export const games = mysqlTable("games", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["arcade_crash", "card_games", "slots", "lottery"]).notNull(),
  rtp: decimal("rtp", { precision: 5, scale: 2 }).notNull(), // e.g., 96.50
  minBet: decimal("minBet", { precision: 15, scale: 2 }).default("10").notNull(),
  maxBet: decimal("maxBet", { precision: 15, scale: 2 }).default("10000").notNull(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  isActive: boolean("isActive").default(true).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Game = typeof games.$inferSelect;
export type InsertGame = typeof games.$inferInsert;

/**
 * Individual game bets and results
 */
export const bets = mysqlTable("bets", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  gameId: varchar("gameId", { length: 64 }).notNull(),
  betAmount: decimal("betAmount", { precision: 15, scale: 2 }).notNull(),
  resultAmount: decimal("resultAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  status: mysqlEnum("status", ["pending", "won", "lost", "cancelled"]).default("pending").notNull(),
  
  // Game-specific data
  gameData: json("gameData"), // Store game state, choices, etc.
  resultData: json("resultData"), // Store game result, multiplier, etc.
  
  // Provably fair
  clientSeed: varchar("clientSeed", { length: 255 }),
  serverSeed: varchar("serverSeed", { length: 255 }),
  nonce: int("nonce"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: datetime("completedAt"),
});

export type Bet = typeof bets.$inferSelect;
export type InsertBet = typeof bets.$inferInsert;

/**
 * Agent referral tracking
 */
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  agentUserId: int("agentUserId").notNull(),
  referredUserId: int("referredUserId").notNull(),
  level: int("level").default(1).notNull(), // 1 = direct, 2 = indirect, etc.
  totalBetsFromReferral: decimal("totalBetsFromReferral", { precision: 15, scale: 2 }).default("0").notNull(),
  commissionEarned: decimal("commissionEarned", { precision: 15, scale: 2 }).default("0").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

/**
 * Daily commission records for agents
 */
export const dailyCommissions = mysqlTable("dailyCommissions", {
  id: int("id").autoincrement().primaryKey(),
  agentUserId: int("agentUserId").notNull(),
  commissionDate: varchar("commissionDate", { length: 10 }).notNull(), // YYYY-MM-DD
  totalBetsFromDownline: decimal("totalBetsFromDownline", { precision: 15, scale: 2 }).default("0").notNull(),
  commissionAmount: decimal("commissionAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  status: mysqlEnum("status", ["pending", "credited"]).default("pending").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyCommission = typeof dailyCommissions.$inferSelect;
export type InsertDailyCommission = typeof dailyCommissions.$inferInsert;

/**
 * Daily check-in bonuses
 */
export const dailyCheckIns = mysqlTable("dailyCheckIns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  checkInDate: varchar("checkInDate", { length: 10 }).notNull(), // YYYY-MM-DD
  bonusAmount: decimal("bonusAmount", { precision: 15, scale: 2 }).notNull(),
  streakDays: int("streakDays").default(1).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DailyCheckIn = typeof dailyCheckIns.$inferSelect;
export type InsertDailyCheckIn = typeof dailyCheckIns.$inferInsert;

/**
 * Promotions and bonuses
 */
export const promotions = mysqlTable("promotions", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  bonusAmount: decimal("bonusAmount", { precision: 15, scale: 2 }).notNull(),
  bonusType: mysqlEnum("bonusType", ["deposit_match", "free_bet", "cashback", "reload"]).notNull(),
  minDepositRequired: decimal("minDepositRequired", { precision: 15, scale: 2 }).default("0"),
  maxBonusAmount: decimal("maxBonusAmount", { precision: 15, scale: 2 }),
  wagering_multiplier: int("wagering_multiplier").default(1),
  isActive: boolean("isActive").default(true).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Promotion = typeof promotions.$inferSelect;
export type InsertPromotion = typeof promotions.$inferInsert;

/**
 * Live game sessions for tracking active players
 */
export const gameSessions = mysqlTable("gameSessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  gameId: varchar("gameId", { length: 64 }).notNull(),
  activePlayers: int("activePlayers").default(0).notNull(),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
});

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;

/**
 * Game result overrides (admin only)
 */
export const gameResultOverrides = mysqlTable("gameResultOverrides", {
  id: int("id").autoincrement().primaryKey(),
  betId: varchar("betId", { length: 64 }).notNull(),
  originalResult: json("originalResult"),
  overrideResult: json("overrideResult").notNull(),
  reason: text("reason"),
  adminUserId: int("adminUserId").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GameResultOverride = typeof gameResultOverrides.$inferSelect;
export type InsertGameResultOverride = typeof gameResultOverrides.$inferInsert;
