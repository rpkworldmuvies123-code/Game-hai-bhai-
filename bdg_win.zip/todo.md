# BDG Win - Project TODO

## Core Infrastructure & Authentication
- [x] Database schema: users, wallets, transactions, games, bets, agents, referrals
- [x] Manus OAuth integration and session management
- [x] User profile management with bank card info storage
- [x] Role-based access control (user, agent, admin)

## Wallet & Payments
- [x] Wallet balance display and real-time updates
- [x] Deposit flow with payment gateway simulation
- [x] Withdrawal request system with bank card validation
- [x] Get ₹500 bonus system (one-time per user)
- [x] Transaction history and ledger

## UI Framework & Design
- [x] Art Deco dark theme with gold accents
- [x] Global CSS variables and typography setup
- [x] Bottom navigation bar (Home, Activity, Promotions, Account, Admin)
- [x] Responsive mobile-first layout
- [x] Premium card components with geometric ornamentation

## Game Lobby
- [x] Home page with categorized game sections
- [x] Game cards with RTP display and live player count
- [x] Arcade/Crash category
- [x] Card Games category
- [x] Slots category
- [x] Lottery category

## Arcade/Crash Games
- [x] Aviator game (crash multiplier mechanic) - logic implemented
- [x] Mines game (grid reveal with mines) - logic implemented
- [x] Plinko game (ball drop with multipliers) - logic implemented
- [x] Limbo game (multiplier prediction) - logic implemented

## Card Games
- [x] Teen Patti (3-card Indian poker vs AI) - logic implemented
- [x] Rummy (13-card rummy vs AI) - logic implemented
- [x] Andar Bahar (traditional Indian card game) - logic implemented
- [x] Dragon vs Tiger (card comparison game) - logic implemented

## Slots & Lottery Games
- [x] Classic slot machine with reels - logic implemented
- [x] Color prediction game (red/green/violet) - logic implemented
- [x] Wingo lottery with countdown timer - logic implemented

## Agent/Referral System
- [x] Unique referral code generation per user
- [x] Multi-level downline tracking - database structure ready
- [x] Daily commission calculation (0.5% of referral bets) - logic implemented
- [x] Agent dashboard with earnings and referral list - UI created
- [ ] Agent application flow - needs UI implementation

## Promotions & Activity
- [x] Daily check-in bonus system - UI component created
- [x] VIP level progression tracking - database structure ready
- [x] Promotions page with bonus listings - UI created
- [x] Activity page with bet history - UI created
- [x] Transaction history view - UI created

## Admin Panel
- [ ] User management interface - basic structure ready
- [ ] Game result override tools - database ready
- [x] Deposit/withdrawal approval system - UI implemented
- [ ] Platform-wide statistics dashboard - needs implementation
- [x] Role-based admin access - implemented
- [ ] User suspension/ban system
- [ ] Revenue analytics
- [ ] Player retention metrics

## Game UI Components
- [x] Aviator game UI with crash mechanics
- [x] Mines game UI with grid reveal
- [x] Color Game UI with prediction
- [x] Slots game UI with spinning reels
- [ ] Teen Patti card game UI
- [ ] Rummy card game UI
- [ ] Andar Bahar card game UI
- [ ] Dragon vs Tiger card game UI
- [ ] Plinko game UI
- [ ] Limbo game UI
- [ ] Wingo lottery UI with countdown

## Testing & Polish
- [x] Unit tests for game logic and RTP calculations - 24 tests passing
- [ ] Integration tests for wallet and transactions
- [ ] Responsive design testing across devices
- [ ] Animation polish and micro-interactions
- [ ] Performance optimization
- [ ] Security audit (bank card encryption, withdrawal validation)
